// lib/config/app_config.dart
abstract class AppConfig {
  String get baseUrl;
  String get firebaseChatDB;
  String get agoraAppID;
}
