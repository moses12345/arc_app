import 'dart:ui';

const themeColor = Color(0xff337AB7);
const primaryColor = Color(0xff203152);
const greyColor = Color(0xffaeaeae);
const greyColorLabel = Color(0xff7f7f7f);
const greyColor2 = Color(0xffE8E8E8);
const headerColor = Color(0xff118b75);
const yellowColor = Color(0xffffd54d);
const blueColor = Color(0xff1d76ba);
const bottomBarUnselected = Color(0xff677B8A);
const white = Color(0xffffffff);
const labelColor = Color(0xffB2BAC6);
const boxColor = Color(0xffE7E4FA);
const violet = Color(0xff652D90);
const black = Color(0xff000000);
