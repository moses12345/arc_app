enum Status { loading, success, error, empty }

enum QuestionType { normal, mcq }

enum BookMarkType { job, qna }

